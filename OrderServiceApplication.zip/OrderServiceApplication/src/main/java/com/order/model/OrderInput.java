package com.order.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class OrderInput {
	
	private String customerName;
	private String shippingAddress;
	private List<ProductDto> orderedItems;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public List<ProductDto> getOrderedItems() {
		return orderedItems;
	}
	public void setOrderedItems(List<ProductDto> orderedItems) {
		this.orderedItems = orderedItems;
	}
	

}
