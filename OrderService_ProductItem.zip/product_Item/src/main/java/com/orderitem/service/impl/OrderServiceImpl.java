package com.orderitem.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orderitem.dto.ProductsDto;
import com.orderitem.model.Product;
import com.orderitem.repository.ProductRepository;


@Service
public class OrderServiceImpl {
	
	@Autowired
	ProductRepository productrepo;
	public List<Product> orderProducts(List<Map<String, Object>> list) {
		List<Product> productlist=new ArrayList<Product>();
		List<ProductsDto> orderList=new ArrayList<ProductsDto>();
		list.forEach(proddto->{
			ProductsDto prod=new ProductsDto(Long.parseLong(proddto.get("productId").toString()),
					Integer.parseInt(proddto.get("quantity").toString()));
			orderList.add(prod);
		});
		orderList.forEach(order->{
		Optional<Product> optionalprod=productrepo.findById(order.getProductId());
		if(optionalprod.isPresent() && optionalprod.get().getQuantity()>=order.getQuantity()) {
			Product product=optionalprod.get();			
			product.setQuantity(product.getQuantity()-order.getQuantity());
			productrepo.save(product);
			product.setQuantity(order.getQuantity());
			productlist.add(product);
		}		
		});
		return productlist;
	}
	
	

}
