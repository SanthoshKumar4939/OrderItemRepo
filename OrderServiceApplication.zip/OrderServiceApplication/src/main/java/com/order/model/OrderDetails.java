package com.order.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class OrderDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long orderId;
	private String customerName;
	private String shippingAddress;
	private double totalPrice;
	private Date orderdate;
	@OneToMany
	private java.util.List<OrderedItems> orderedItems;
	public long getOrderId() {
		return orderId;
	}
	public OrderDetails(String customerName, String shippingAddress, double totalPrice, Date orderdate,
			List<OrderedItems> orderedItems) {
		super();
		this.customerName = customerName;
		this.shippingAddress = shippingAddress;
		this.totalPrice = totalPrice;
		this.orderdate = orderdate;
		this.orderedItems = orderedItems;
	}
	

	public java.util.List<OrderedItems> getOrderedItems() {
		return orderedItems;
	}
	public void setOrderedItems(java.util.List<OrderedItems> orderedItems) {
		this.orderedItems = orderedItems;
	}


	
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Date getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}
	
	public OrderDetails() {
		
	}
	
	
	

}
