package com.order.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderedItems {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ordereditemid;
	private long productid;
	private long quantity;
	public long getOrdereditemid() {
		return ordereditemid;
	}
	public void setOrdereditemid(long ordereditemid) {
		this.ordereditemid = ordereditemid;
	}
	public long getProductid() {
		return productid;
	}
	public void setProductid(long productid) {
		this.productid = productid;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public OrderedItems(long productid, long quantity) {
		super();
		this.productid = productid;
		this.quantity = quantity;
	}
	public OrderedItems() {
		
	}
	

}
