package com.orderitem.builder;

import com.orderitem.model.Product;

public class ProductBuilder {

	private String productName;
	private int quantity;
	private double price;
	public ProductBuilder setProductName(String productName) {
		this.productName = productName;
		return this;
	}
	public ProductBuilder setQuantity(int quantity) {
		this.quantity = quantity;
		return this;
	}
	public ProductBuilder setPrice(double price) {
		this.price = price;
		return this;
	}
	public Product productBuild() {
		Product product=new Product(productName, quantity, price);
		return product;
	}
	
}
