package com.order.service.impl;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.Exception.OrderNotFoundException;
import com.order.client.OrderItemRestClient;
import com.order.model.OrderDetails;
import com.order.model.OrderInput;
import com.order.model.OrderedItems;
import com.order.model.Product;
import com.order.model.ProductDto;
import com.order.repository.OrderRepository;
import com.order.repository.OrderedItemRepository;
import com.order.service.OrderService;

@Service
public class OrderServiceImpl<R> implements OrderService {
	
	@Autowired
	OrderRepository orderrepository;
	@Autowired
	OrderedItemRepository orderedItemRepository;
	@Autowired
	OrderItemRestClient restclientservice;
	@Override
	public OrderDetails placeorder(OrderInput orderInput) {
		List<ProductDto> requestedproductslist=orderInput.getOrderedItems();		
		List<Product> orderedproductslist=restclientservice.placeorder(requestedproductslist);
		OrderDetails orderDetails=new OrderDetails(orderInput.getCustomerName(), 
				orderInput.getShippingAddress(),0, 
				new Date(), new ArrayList<OrderedItems>());
		List<OrderedItems> orderedlist	=orderedproductslist.stream().map(product->{
			orderDetails.setTotalPrice(orderDetails.getTotalPrice()+(product.getPrice()*product.getQuantity()));
			OrderedItems ordereditems=new OrderedItems(product.getProductId(), product.getQuantity());
				orderedItemRepository.save(ordereditems);
				return ordereditems;}).collect(Collectors.toList());
		orderDetails.setOrderedItems(orderedlist);
		return orderrepository.save(orderDetails);
	}
	
	@Override
	public OrderDetails getorderdetails(long id) {
		
		Optional<OrderDetails> optionalorder=orderrepository.findById(id);
		if(optionalorder.isPresent()) {
			return optionalorder.get();
		}else {
			throw new OrderNotFoundException("Invalid Order Id");
		}
		
	}
}
