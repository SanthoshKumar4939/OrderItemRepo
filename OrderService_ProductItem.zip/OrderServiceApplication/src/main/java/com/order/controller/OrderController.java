package com.order.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.order.model.OrderDetails;
import com.order.model.OrderedItems;
import com.order.service.impl.OrderServiceImpl;

@RestController
public class OrderController {

	@Autowired
	OrderServiceImpl orderserviceimpl;
	@PostMapping("/order")
	public ResponseEntity<?> placeOrder(@RequestBody Map<String, Object> data) {
		
		return new ResponseEntity<OrderDetails>(orderserviceimpl.placeorder(data),HttpStatus.OK);
		
		
	}
	
	@GetMapping("/order/{id}")
	public ResponseEntity<?> getOrderDetails(@PathVariable long id){
		
		
		return new ResponseEntity<OrderDetails>(orderserviceimpl.getorderdetails(id),HttpStatus.OK);
	}
}
