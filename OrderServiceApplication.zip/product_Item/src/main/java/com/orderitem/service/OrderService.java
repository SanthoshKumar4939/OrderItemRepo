package com.orderitem.service;

import java.util.List;
import java.util.Map;

import com.orderitem.model.Product;

public interface OrderService {
	
	 List<Product> orderProducts(List<Map<String, Object>> list);

}
