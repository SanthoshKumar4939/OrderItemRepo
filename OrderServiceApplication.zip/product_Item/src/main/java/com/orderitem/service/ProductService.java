package com.orderitem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.orderitem.model.Product;

@Service
public interface ProductService {

	Product addProduct(Product product);
	
	Product getProduct(long id);
	List<Product> getAllProducts();
	
}
