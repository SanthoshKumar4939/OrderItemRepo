package com.orderitem.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.orderitem.dto.ProductsDto;
import com.orderitem.model.Product;
import com.orderitem.service.OrderService;
import com.orderitem.service.impl.OrderServiceImpl;

@RestController
public class OrderController {
	@Autowired
	OrderService orderService;
	@PostMapping("/order")
	public ResponseEntity<?> placeorder(@RequestBody List<Map<String, Object>> list){
		
		return new ResponseEntity<List<Product>>(orderService.orderProducts(list),HttpStatus.OK);
	}

}
