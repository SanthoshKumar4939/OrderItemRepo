package com.orderitem.mapper;

import java.util.Map;

import com.orderitem.builder.ProductBuilder;
import com.orderitem.model.Product;



public class ProductMapper {
	
	public static Product productMapper(Map<String,Object> data) {
		 String productName=data.get("productName").toString();
		 Double price=Double.parseDouble(data.get("price").toString());		 
		 Integer quantity=Integer.parseInt(data.get("quantity").toString());
		 ProductBuilder productbuilder=new ProductBuilder();
		 
		 return productbuilder.setPrice(price)
				 .setProductName(productName).setQuantity(quantity).productBuild();
	}

}
