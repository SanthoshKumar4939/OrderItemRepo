package com.orderitem.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orderitem.Exception.ProductNotFoundException;
import com.orderitem.model.Product;
import com.orderitem.repository.ProductRepository;
import com.orderitem.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductRepository productrepository;
	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		System.out.println(product.getQuantity());
		return productrepository.save(product);
	}
	@Override
	public Product getProduct(long id) {
		// TODO Auto-generated method stub
		
		Optional<Product> productopt=productrepository.findById(id);
		if(productopt.isPresent()) {
			return productopt.get();
		}
		else
			throw new ProductNotFoundException("Invalid Product Id");
	}
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		
		return productrepository.findAll();
	}
	

}
