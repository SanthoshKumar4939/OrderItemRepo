package com.orderitem.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionAdvisor {

	@ExceptionHandler(ProductNotFoundException.class)
	public ErrorResponse handleNotFoundException(ProductNotFoundException e){
		ErrorResponse errorresponse=new ErrorResponse(e.getMessage(), HttpStatus.NOT_FOUND);
		return errorresponse;
	}
}
