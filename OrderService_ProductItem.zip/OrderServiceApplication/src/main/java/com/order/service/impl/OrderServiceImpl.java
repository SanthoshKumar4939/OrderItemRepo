package com.order.service.impl;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.Exception.OrderNotFoundException;
import com.order.config.RestClientService;
import com.order.model.OrderDetails;
import com.order.model.OrderedItems;
import com.order.model.Product;
import com.order.model.ProductDto;
import com.order.repository.OrderRepository;
import com.order.repository.OrderedItemRepository;

@Service
public class OrderServiceImpl {
	
	@Autowired
	OrderRepository orderrepository;
	@Autowired
	OrderedItemRepository orderedItemRepository;
	@Autowired
	RestClientService restclientservice;
	public OrderDetails placeorder(Map<String, Object> data) {
		
		List<Map<String, Object>> plist=(List<Map<String, Object>>) data.get("orderedItems");
		List<ProductDto> productslist=new ArrayList<ProductDto>();
		plist.forEach(obj->{
			ProductDto proddto=new ProductDto(Long.parseLong(obj.get("productId").toString()),
					Integer.parseInt(obj.get("quantity").toString()));
			productslist.add(proddto);
			
		});
	
		
		List<Product> products=restclientservice.placeorder(productslist);
		double totalPrice = 0;
		List<OrderedItems> orderedlist=new ArrayList<OrderedItems>();
		for(Product prod:products) {
			totalPrice+=prod.getPrice()*prod.getQuantity();
			OrderedItems ordereditems=new OrderedItems(prod.getProductId(), prod.getQuantity());
			orderedlist.add(ordereditems);
			orderedItemRepository.save(ordereditems);
		}
		
		OrderDetails orderDetails=new OrderDetails(data.get("customerName").toString(), 
				data.get("shippingAddress").toString(),totalPrice, 
				new Date(), orderedlist);
		
		return orderrepository.save(orderDetails);
	}
	
	public OrderDetails getorderdetails(long id) {
		
		Optional<OrderDetails> optionalorder=orderrepository.findById(id);
		if(optionalorder.isPresent()) {
			return optionalorder.get();
		}else {
			throw new OrderNotFoundException("Invalid Order Id");
		}
		
	}
}
