package com.orderitem.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.orderitem.mapper.ProductMapper;
import com.orderitem.model.Product;
import com.orderitem.service.ProductService;
import com.orderitem.service.impl.ProductServiceImpl;


@RestController
public class ProductController {
	
	@Autowired
	ProductService productservice;
	
	@PostMapping("/product")
	public ResponseEntity<?> addProduct( @RequestBody Map<String, Object> data){
		Product product=ProductMapper.productMapper(data);
		return new ResponseEntity<Product>(productservice.addProduct(product),HttpStatus.CREATED);
	}
	@GetMapping("/product/{id}")
	public ResponseEntity<?> getProduct(@PathVariable long id){
		
		return new ResponseEntity<Product>(productservice.getProduct(id),HttpStatus.OK);
		
	}
	@GetMapping("/product")
public ResponseEntity<?> getAllProducts(){
		
		return new ResponseEntity<List<Product>>(productservice.getAllProducts(),HttpStatus.OK);
		
	}

}
