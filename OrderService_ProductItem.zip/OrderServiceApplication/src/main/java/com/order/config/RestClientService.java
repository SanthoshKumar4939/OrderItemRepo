package com.order.config;



import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.order.model.Product;
import com.order.model.ProductDto;

import feign.Headers;

@Headers("Content-Type: application/json")
@FeignClient(name = "${feign.name}", url = "${feign.url}")
public interface RestClientService {

    @RequestMapping(value = "/order", method = RequestMethod.POST)
    List<Product> placeorder(@RequestBody List<ProductDto> data);

}
