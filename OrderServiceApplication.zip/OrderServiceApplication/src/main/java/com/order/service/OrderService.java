package com.order.service;

import java.util.Map;

import com.order.model.OrderDetails;
import com.order.model.OrderInput;

public interface OrderService {
	OrderDetails placeorder(OrderInput orderInput);
	OrderDetails getorderdetails(long id);

}
