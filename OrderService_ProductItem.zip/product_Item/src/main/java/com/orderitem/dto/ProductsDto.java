package com.orderitem.dto;

public class ProductsDto {

	private long productId;
	private int quantity;
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public ProductsDto(long productId, int quantity) {
		super();
		this.productId = productId;
		this.quantity = quantity;
	}
	public ProductsDto(){
		
	}
	
}
