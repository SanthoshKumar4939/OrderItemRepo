package com.order.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.order.model.OrderDetails;
import com.order.model.OrderInput;
import com.order.model.OrderedItems;
import com.order.service.OrderService;
import com.order.service.impl.OrderServiceImpl;

@RestController
public class OrderController {

	@Autowired
	OrderService orderservice;
	@PostMapping("/order")
	public ResponseEntity<OrderDetails> placeOrder(@RequestBody OrderInput orderInput) {
		
		return new ResponseEntity<OrderDetails>(orderservice.placeorder(orderInput),HttpStatus.OK);
		
		
	}
	
	@GetMapping("/order/{id}")
	public ResponseEntity<OrderDetails> getOrderDetails(@PathVariable long id){
		return new ResponseEntity<OrderDetails>(orderservice.getorderdetails(id),HttpStatus.OK);
	}
}
